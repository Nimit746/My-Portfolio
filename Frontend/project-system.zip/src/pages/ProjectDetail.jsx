import React from "react";
import { useParams, Link } from "react-router-dom";
import { useProjects } from "../context/ProjectContext";

const ProjectDetail = () => {
  const { slug } = useParams();
  const { getProjectBySlug } = useProjects();
  const project = getProjectBySlug(slug);

  if (!project) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center p-6">
        <h1 className="text-3xl text-red-500 font-bold mb-4">Project Not Found</h1>
        <p className="text-gray-700 mb-6">No such project exists.</p>
        <Link to="/projects" className="text-indigo-600 underline">← Go back to Projects</Link>
      </div>
    );
  }

  return (
    <main className="bg-gray-50 px-6 py-16 min-h-[87vh]">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <img src={project.image} alt={project.title} className="w-full h-64 object-cover rounded-md mb-6" />
        <h2 className="text-4xl font-bold mb-4 text-indigo-600">{project.title}</h2>
        <p className="text-lg mb-4">{project.description}</p>
        {project.tech && (
          <div className="mb-6">
            <h4 className="font-semibold text-gray-800 mb-2">Technologies Used:</h4>
            <ul className="flex flex-wrap gap-2">
              {project.tech.map((tech, i) => (
                <li key={i} className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm">
                  {tech}
                </li>
              ))}
            </ul>
          </div>
        )}
        <Link to="/projects" className="mt-4 inline-block px-6 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">
          ← Back to Projects
        </Link>
      </div>
    </main>
  );
};

export default ProjectDetail;