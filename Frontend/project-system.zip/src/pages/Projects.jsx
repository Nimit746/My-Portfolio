import React from "react";
import { useProjects } from "../context/ProjectContext";
import Toggleform from "./Toggleform";
import Card from "./Card";
import { Link } from "react-router-dom";
import slugify from "slugify";

const Projects = (props) => {
  const { projects, addProject } = useProjects();

  return (
    <main className="bg-indigo-200 min-h-[97vh] w-full p-10" style={{ padding: props.lp }}>
      <div className="flex justify-between mt-17 flex-col md:flex-row">
        <h1 className="text-4xl font-bold mb-10 text-center md:text-left">My Projects</h1>
        <div className="flex gap-3 items-center">
          <label className="text-xl font-bold">Add Projects:</label>
          <Toggleform onFormSubmit={addProject} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 mt-10">
        {projects.map((p, idx) => (
          <Link key={idx} to={`/projects/${slugify(p.title, { lower: true })}`}>
            <Card
              cw="70%"
              ch="auto"
              name={p.title}
              message={p.description}
              image={p.image}
              image_width="100%"
              image_height="30px"
              glass="glass"
              cflex="column"
              namecol="black"
              mcol="black"
              canimation="slidel 0.5s ease-in-out forwards"
            />
          </Link>
        ))}
      </div>
    </main>
  );
};

export default Projects;