import { createContext, useContext, useState } from "react";
import slugify from "slugify";

const ProjectContext = createContext();

const defaultProjects = [
  {
    title: "Portfolio Website",
    description: "A personal portfolio built with React, Tailwind CSS, and React Router.",
    tech: ["React", "Tailwind", "Vite"],
    image: "/assets/Background/bg.jpg",
  },
  {
    title: "E-Commerce App",
    description: "A full-stack MERN application with admin panel and payment integration.",
    tech: ["MongoDB", "Express", "React", "Node.js"],
    image: "/assets/Background/bg.jpg",
  },
];

export const ProjectProvider = ({ children }) => {
  const [projects, setProjects] = useState(defaultProjects);

  const addProject = (project) => {
    setProjects((prev) => [...prev, project]);
  };

  const getProjectBySlug = (slug) => {
    return projects.find((p) => slugify(p.title, { lower: true }) === slug);
  };

  return (
    <ProjectContext.Provider value={{ projects, addProject, getProjectBySlug }}>
      {children}
    </ProjectContext.Provider>
  );
};

export const useProjects = () => useContext(ProjectContext);